package com.azhar.studytracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            android.content.SharedPreferences p = context.getSharedPreferences("azhar_study_prefs", Context.MODE_PRIVATE);
            java.util.Calendar c = java.util.Calendar.getInstance(); c.set(java.util.Calendar.HOUR_OF_DAY, p.getInt("hour",20)); c.set(java.util.Calendar.MINUTE, p.getInt("minute",0)); c.set(java.util.Calendar.SECOND,0); c.set(java.util.Calendar.MILLISECOND,0); if (!c.after(java.util.Calendar.getInstance())) c.add(java.util.Calendar.DAY_OF_YEAR,1);
            android.app.AlarmManager am = (android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            android.content.Intent i = new android.content.Intent(context, ReminderReceiver.class);
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(context,301,i,android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
            if (am != null) { try { if (android.os.Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi); else am.set(android.app.AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi); } catch (SecurityException ignored) { am.set(android.app.AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi); } }
        }
    }
}
