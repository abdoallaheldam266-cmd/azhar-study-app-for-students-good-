package com.azhar.studytracker;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final int RC_SIGN_IN = 812;
    private static final int RC_NOTIFICATIONS = 813;
    private static final String PREFS = "azhar_study_prefs";
    // Replace this placeholder with the Web client ID from Firebase/Google Cloud.
    private static final String WEB_CLIENT_ID = "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com";
    // Optional Firebase values. Fill these from Firebase project settings to enable sync.
    private static final String FIREBASE_API_KEY = "YOUR_FIREBASE_API_KEY";
    private static final String FIREBASE_APP_ID = "YOUR_FIREBASE_APP_ID";
    private static final String FIREBASE_PROJECT_ID = "YOUR_FIREBASE_PROJECT_ID";

    private LinearLayout root, list;
    private TextView status, reminderLabel;
    private SharedPreferences prefs;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private GoogleSignInClient googleClient;
    private int reminderHour = 20, reminderMinute = 0;

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        reminderHour = prefs.getInt("hour", 20); reminderMinute = prefs.getInt("minute", 0);
        initFirebaseIfConfigured();
        buildUi();
        requestNotificationPermission();
        scheduleReminder();
    }

    private void initFirebaseIfConfigured() {
        try {
            if (!FIREBASE_API_KEY.startsWith("YOUR_") && !FIREBASE_APP_ID.startsWith("YOUR_") && !FIREBASE_PROJECT_ID.startsWith("YOUR_")) {
                if (FirebaseApp.getApps(this).isEmpty()) {
                    FirebaseOptions options = new FirebaseOptions.Builder().setApiKey(FIREBASE_API_KEY).setApplicationId(FIREBASE_APP_ID).setProjectId(FIREBASE_PROJECT_ID).build();
                    FirebaseApp.initializeApp(this, options);
                }
                auth = FirebaseAuth.getInstance(); db = FirebaseFirestore.getInstance();
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestIdToken(WEB_CLIENT_ID).build();
                googleClient = GoogleSignIn.getClient(this, gso);
            }
        } catch (Exception ignored) { auth = null; db = null; googleClient = null; }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(18), dp(18), dp(24)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("جدول مذاكرة الأزهر", 26, true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView subtitle = text("علّم على كل مادة بعد ما تخلصها، وتابع إنجازك يومًا بيوم.", 15, false); subtitle.setGravity(Gravity.CENTER); root.addView(subtitle, params(-1, -2, 0, 8, 0, 16));
        status = text("الحساب: غير مسجل الدخول", 14, false); root.addView(status);
        Button signIn = new Button(this); signIn.setText("تسجيل الدخول بحساب Google"); signIn.setOnClickListener(v -> signInGoogle()); root.addView(signIn, params(-1, -2, 0, 8, 0, 8));
        TextView today = text("مواد اليوم: " + dayName(Calendar.getInstance().get(Calendar.DAY_OF_WEEK)), 19, true); root.addView(today, params(-1, -2, 0, 8, 0, 4));
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        Button report = new Button(this); report.setText("عرض تقرير اليوم"); report.setOnClickListener(v -> showReport()); root.addView(report, params(-1, -2, 0, 10, 0, 4));
        reminderLabel = text("موعد التذكير: " + formatTime(), 16, true); root.addView(reminderLabel, params(-1, -2, 0, 14, 0, 4));
        Button chooseTime = new Button(this); chooseTime.setText("اختيار موعد الإشعار"); chooseTime.setOnClickListener(v -> chooseReminderTime()); root.addView(chooseTime, params(-1, -2, 0, 4, 0, 8));
        TextView note = text("الإشعار يذكر المواد غير المكتملة في اليوم. فعّل إذن الإشعارات من إعدادات التاب إذا طُلب منك ذلك.", 13, false); root.addView(note, params(-1, -2, 0, 8, 0, 8));
        refreshList(); refreshAccountLabel();
    }

    private void refreshList() {
        list.removeAllViews(); List<String> subjects = subjectsFor(Calendar.getInstance()); String date = dateKey();
        if (subjects.isEmpty()) { list.addView(text("لا توجد مواد محددة لهذا اليوم.", 16, false)); return; }
        for (String subject : subjects) {
            CheckBox cb = new CheckBox(this); cb.setText(subject); cb.setTextSize(18); cb.setPadding(4, dp(8), 4, dp(8));
            cb.setChecked(prefs.getBoolean(date + "_" + subject, false));
            cb.setOnCheckedChangeListener((button, checked) -> { prefs.edit().putBoolean(date + "_" + subject, checked).apply(); syncDayIfSignedIn(); });
            list.addView(cb);
        }
    }

    private List<String> subjectsFor(Calendar c) {
        int day = c.get(Calendar.DAY_OF_WEEK); List<String> s = new ArrayList<>();
        // Calendar: Sunday=1, Monday=2 ... Saturday=7
        if (day == Calendar.MONDAY || day == Calendar.TUESDAY || day == Calendar.FRIDAY) s.add("اللغة العربية");
        if (day == Calendar.SATURDAY || day == Calendar.MONDAY || day == Calendar.WEDNESDAY) s.add("الرياضيات");
        if (day == Calendar.SUNDAY || day == Calendar.TUESDAY || day == Calendar.THURSDAY) { s.add("العلوم المتكاملة"); s.add("اللغة الإنجليزية"); }
        if (day == Calendar.SATURDAY || day == Calendar.MONDAY || day == Calendar.WEDNESDAY) { s.add("الفلسفة والمنطق"); s.add("التاريخ"); }
        if (day != Calendar.FRIDAY) s.add("المواد الشرعية");
        return s;
    }

    private void chooseReminderTime() {
        new TimePickerDialog(this, (view, hour, minute) -> {
            reminderHour = hour; reminderMinute = minute; prefs.edit().putInt("hour", hour).putInt("minute", minute).apply();
            reminderLabel.setText("موعد التذكير: " + formatTime()); scheduleReminder();
            Toast.makeText(this, "تم حفظ موعد التذكير", Toast.LENGTH_SHORT).show();
        }, reminderHour, reminderMinute, false).show();
    }

    private void scheduleReminder() {
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(this, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(this, 301, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Calendar when = Calendar.getInstance(); when.set(Calendar.HOUR_OF_DAY, reminderHour); when.set(Calendar.MINUTE, reminderMinute); when.set(Calendar.SECOND, 0); when.set(Calendar.MILLISECOND, 0);
        if (!when.after(Calendar.getInstance())) when.add(Calendar.DAY_OF_YEAR, 1);
        if (am != null) {
            try { if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi); else am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi); } catch (SecurityException ignored) { am.set(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), pi); }
        }
    }

    private void signInGoogle() {
        if (googleClient == null) { new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("إعداد الحساب مطلوب").setMessage("تسجيل Google والمزامنة السحابية يحتاجان إعداد مشروع Firebase خاص بالتطبيق قبل بناء نسخة التثبيت.").setPositiveButton("حسنًا", null).show(); return; }
        startActivityForResult(googleClient.getSignInIntent(), RC_SIGN_IN);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                auth.signInWithCredential(credential).addOnSuccessListener(result -> { refreshAccountLabel(); syncDayIfSignedIn(); Toast.makeText(this, "تم تسجيل الدخول", Toast.LENGTH_SHORT).show(); }).addOnFailureListener(e -> Toast.makeText(this, "تعذر تسجيل الدخول: " + e.getLocalizedMessage(), Toast.LENGTH_LONG).show());
            } catch (Exception e) { Toast.makeText(this, "لم يكتمل تسجيل الدخول", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void refreshAccountLabel() {
        if (status == null) return;
        if (auth != null && auth.getCurrentUser() != null) status.setText("الحساب: " + auth.getCurrentUser().getEmail());
        else status.setText("الحساب: غير مسجل الدخول (البيانات محفوظة على هذا التاب)");
    }

    private void syncDayIfSignedIn() {
        if (auth == null || auth.getCurrentUser() == null || db == null) return;
        Map<String, Object> data = new HashMap<>(); data.put("date", dateKey()); data.put("updatedAt", new Date());
        Map<String, Boolean> checks = new HashMap<>(); for (String subject : subjectsFor(Calendar.getInstance())) checks.put(subject, prefs.getBoolean(dateKey() + "_" + subject, false)); data.put("subjects", checks);
        db.collection("users").document(auth.getCurrentUser().getUid()).collection("studyDays").document(dateKey()).set(data);
    }

    private void showReport() {
        List<String> subjects = subjectsFor(Calendar.getInstance()); int done = 0; StringBuilder b = new StringBuilder();
        for (String s : subjects) { boolean ok = prefs.getBoolean(dateKey() + "_" + s, false); if (ok) done++; b.append(ok ? "✅ " : "⬜ ").append(s).append("\n"); }
        b.append("\nالإنجاز: ").append(done).append(" من ").append(subjects.size());
        new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("تقرير اليوم").setMessage(b.toString()).setPositiveButton("إغلاق", null).show();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, RC_NOTIFICATIONS);
    }
    static String dateKey() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()); }
    static String dayName(int day) { switch(day) { case Calendar.SUNDAY:return "الأحد"; case Calendar.MONDAY:return "الاثنين"; case Calendar.TUESDAY:return "الثلاثاء"; case Calendar.WEDNESDAY:return "الأربعاء"; case Calendar.THURSDAY:return "الخميس"; case Calendar.FRIDAY:return "الجمعة"; default:return "السبت"; } }
    static List<String> todaySubjects(Context context) {
        Calendar c = Calendar.getInstance(); int day = c.get(Calendar.DAY_OF_WEEK); List<String> s = new ArrayList<>();
        if (day == Calendar.MONDAY || day == Calendar.TUESDAY || day == Calendar.FRIDAY) s.add("اللغة العربية");
        if (day == Calendar.SATURDAY || day == Calendar.MONDAY || day == Calendar.WEDNESDAY) s.add("الرياضيات");
        if (day == Calendar.SUNDAY || day == Calendar.TUESDAY || day == Calendar.THURSDAY) { s.add("العلوم المتكاملة"); s.add("اللغة الإنجليزية"); }
        if (day == Calendar.SATURDAY || day == Calendar.MONDAY || day == Calendar.WEDNESDAY) { s.add("الفلسفة والمنطق"); s.add("التاريخ"); }
        if (day != Calendar.FRIDAY) s.add("المواد الشرعية"); return s;
    }
    private String formatTime() { return String.format(Locale.getDefault(), "%02d:%02d", (reminderHour % 12 == 0 ? 12 : reminderHour % 12), reminderMinute) + (reminderHour >= 12 ? " م" : " ص"); }
    private TextView text(String value, int size, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); if (bold) t.setTypeface(null, Typeface.BOLD); t.setPadding(0, dp(4), 0, dp(4)); return t; }
    private LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
