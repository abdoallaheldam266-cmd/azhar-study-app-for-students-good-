package com.azhar.studytracker;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Calendar;
import java.util.List;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences("azhar_study_prefs", Context.MODE_PRIVATE);
        List<String> subjects = MainActivity.todaySubjects(context); StringBuilder remaining = new StringBuilder();
        for (String s : subjects) if (!p.getBoolean(MainActivity.dateKey() + "_" + s, false)) { if (remaining.length() > 0) remaining.append("، "); remaining.append(s); }
        if (remaining.length() > 0) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            String channel = "study_reminders";
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(channel, "تذكيرات المذاكرة", NotificationManager.IMPORTANCE_DEFAULT));
            Intent open = new Intent(context, MainActivity.class); PendingIntent pi = PendingIntent.getActivity(context, 302, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder b = new NotificationCompat.Builder(context, channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("لسه عندك مواد للمذاكرة 📚").setContentText(remaining.toString()).setStyle(new NotificationCompat.BigTextStyle().bigText("المواد اللي لسه مخلصتهاش: " + remaining)).setAutoCancel(true).setContentIntent(pi);
            nm.notify(302, b.build());
        }
        int hour = p.getInt("hour", 20), minute = p.getInt("minute", 0); Calendar next = Calendar.getInstance(); next.add(Calendar.DAY_OF_YEAR, 1); next.set(Calendar.HOUR_OF_DAY, hour); next.set(Calendar.MINUTE, minute); next.set(Calendar.SECOND, 0); next.set(Calendar.MILLISECOND, 0);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE); Intent again = new Intent(context, ReminderReceiver.class); PendingIntent alarm = PendingIntent.getBroadcast(context, 301, again, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (am != null) { try { if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), alarm); else am.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), alarm); } catch (SecurityException ignored) { am.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), alarm); } }
    }
}
